// Starter for a scheduled event-import pipeline.
// Configure trusted sources and credentials in Supabase Edge Function secrets.
// Never expose provider API keys in the mobile app.
import { serve } from "https://deno.land/std@0.224.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

serve(async (req) => {
  if (req.method !== "POST") return new Response("Method not allowed", { status: 405 });
  const secret = Deno.env.get("IMPORT_CRON_SECRET");
  if (!secret || req.headers.get("x-import-secret") !== secret) {
    return new Response("Unauthorized", { status: 401 });
  }

  const url = Deno.env.get("SUPABASE_URL")!;
  const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
  const db = createClient(url, serviceKey);

  // Intentionally no fabricated event feed:
  // add one adapter per licensed/official source, normalize its data,
  // validate source_url + date + location, then upsert with published=false.
  // Review/verification should publish entries; only verified items should be featured.
  const { count, error } = await db.from("places").select("*", { count: "exact", head: true });
  if (error) return Response.json({ error: error.message }, { status: 500 });
  return Response.json({
    ok: true,
    message: "Importer endpoint is secured and ready for official source adapters.",
    existingPlaceCount: count ?? 0,
    imported: 0
  });
});
