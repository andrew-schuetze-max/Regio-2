create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  home_city text,
  created_at timestamptz not null default now()
);

create table if not exists public.places (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  category text not null check (category in ('Restaurant','Bar','Club','Event','Kultur','Sport','Wellness','Aktivität')),
  city text not null,
  region text,
  description text,
  date_label text,
  price_label text,
  image_url text,
  website_url text,
  source_name text,
  source_url text,
  starts_at timestamptz,
  ends_at timestamptz,
  verified boolean not null default false,
  featured boolean not null default false,
  published boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (source_url)
);

create table if not exists public.favorites (
  user_id uuid not null references auth.users(id) on delete cascade,
  place_id uuid not null references public.places(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, place_id)
);

alter table public.profiles enable row level security;
alter table public.places enable row level security;
alter table public.favorites enable row level security;

create policy "Profiles: owner can read own profile" on public.profiles
  for select to authenticated using (auth.uid() = id);
create policy "Profiles: owner can update own profile" on public.profiles
  for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);
create policy "Published places are readable" on public.places
  for select to anon, authenticated using (published = true);
create policy "Users read own favorites" on public.favorites
  for select to authenticated using (auth.uid() = user_id);
create policy "Users add own favorites" on public.favorites
  for insert to authenticated with check (auth.uid() = user_id);
create policy "Users remove own favorites" on public.favorites
  for delete to authenticated using (auth.uid() = user_id);

create index if not exists places_city_category_idx on public.places(city, category);
create index if not exists places_published_created_idx on public.places(published, created_at desc);
