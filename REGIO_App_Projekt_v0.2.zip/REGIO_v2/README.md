# REGIO – App-Projekt (v0.2)

REGIO ist eine Expo-/React-Native-App für iOS und Android mit dunklem Premium-UI und DACH-Ausrichtung.

## Enthalten
- Home/Heute, Entdecken, Merkliste und Profil
- Suche, Kategorien und Städtefilter
- lokal gespeicherte Favoriten
- optionale Supabase-Anbindung für veröffentlichte Einträge
- Datenbankmigration mit RLS-Regeln
- gesicherter Edge-Function-Einstiegspunkt für spätere offizielle Event-Importe
- explizite Kennzeichnung von Demo-Inhalten

## Lokal starten
1. Node.js LTS installieren.
2. Im Projektordner `npm install` ausführen.
3. `npx expo start` starten.
4. Expo Go auf dem iPhone/Android-Gerät öffnen und QR-Code scannen.

## Live-Datenbank anschließen
1. Supabase-Projekt anlegen.
2. `supabase/migrations/001_init.sql` im SQL-Editor ausführen.
3. `.env.example` nach `.env` kopieren und URL + anon key eintragen.
4. App neu starten.

Die App liest veröffentlichte Datensätze aus `public.places`. Der Mapper in `src/lib/places.ts` übersetzt Datenbankfelder (snake_case) in App-Felder (camelCase).

## Was noch echte externe Einrichtung braucht
Diese Punkte lassen sich nicht seriös ohne Konten, Verträge, Schlüssel und Eigentümerfreigaben fertigschalten:
- verlässliche Event-/Venue-Datenquellen für DE/AT/CH (Lizenzen, API-Nutzungsrechte, Rate Limits)
- produktiver Importer je offizieller/vertraglich zugelassener Quelle und redaktionelle Prüfung
- Supabase-Projekt und Secrets
- Authentifizierung, Passwort-Reset und Cloud-Synchronisierung der Favoriten
- Datenschutztexte, Impressum, Einwilligungen, Lösch- und Exportprozesse
- Push-Notifications und Karten-/Geodaten-Anbieter
- QA auf echten Geräten, Accessibility, Crash-Reporting und Performance
- Apple Developer- und Google Play Console-Konten, Signierung, Store-Metadaten und Freigabe

## Datenqualität & Sicherheit
- Beispieldaten sind ausdrücklich Demo-Einträge und keine realen Empfehlungen.
- Der Importer veröffentlicht keine Daten automatisch. Offizielle Quellen müssen zuerst integriert und Datensätze geprüft werden.
- `service_role`-Schlüssel gehören ausschließlich in Supabase Secrets, niemals in die App oder `.env` der mobilen Anwendung.
- `EXPO_PUBLIC_*`-Variablen sind im App-Bundle sichtbar; dort nur den öffentlichen anon key verwenden.
- Vor Veröffentlichung müssen RLS-Policies, Datenschutz und rechtliche Anforderungen fachkundig geprüft werden.

## Build für Stores
Nach Einrichtung der Konten und Prüfung:
- `npx expo install eas-cli` (oder EAS CLI global installieren)
- `eas build:configure`
- `eas build --platform all`
- anschließend Store-Submission nach Apples/Googles Vorgaben.

Dies ist ein erweiterter, startbarer Entwicklungsstand – noch keine veröffentlichungsfertige Store-App.
