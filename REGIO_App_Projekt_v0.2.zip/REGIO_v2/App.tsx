import React, { useEffect, useMemo, useState } from "react";
import { SafeAreaView, View, Text, TextInput, ScrollView, Pressable, StatusBar, ActivityIndicator, Linking, Alert } from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { StatusBar as ExpoStatusBar } from "expo-status-bar";
import { demoPlaces } from "./src/data/demo";
import { Place, Category } from "./src/types";
import { fetchPlaces } from "./src/lib/places";

const C = { bg: "#101114", panel: "#191B20", panel2: "#22252C", line: "#30343D", text: "#F5F5F3", muted: "#A3A7B0", lime: "#C6F36B", orange: "#FF9C66" };
const categories: Category[] = ["Alle","Restaurant","Bar","Club","Event","Kultur","Sport","Wellness","Aktivität"];
const cities = ["Alle Regionen","Hannover","Berlin","Hamburg","München","Köln","Wien","Zürich","Salzburg"];

function Pill({ label, active, onPress }: { label: string; active?: boolean; onPress: () => void }) {
  return <Pressable onPress={onPress} style={{ paddingHorizontal: 14, paddingVertical: 10, borderRadius: 30, backgroundColor: active ? C.lime : C.panel2, marginRight: 8, marginBottom: 8 }}>
    <Text style={{ color: active ? C.bg : C.text, fontWeight: "700", fontSize: 13 }}>{label}</Text>
  </Pressable>;
}
function Card({ item, saved, onSave, onOpen }: { item: Place; saved: boolean; onSave: () => void; onOpen: () => void }) {
  const glyph: Record<string,string> = { Restaurant:"🍽️", Bar:"🍸", Club:"🎧", Event:"✨", Kultur:"🎭", Sport:"🏃", Wellness:"🧖", Aktivität:"🌿" };
  return <Pressable onPress={onOpen} style={{ backgroundColor: C.panel, borderRadius: 20, padding: 16, marginBottom: 12, borderWidth: 1, borderColor: C.line }}>
    <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center" }}>
      <Text style={{ color: C.lime, fontSize: 12, fontWeight: "800", letterSpacing: 1 }}>{glyph[item.category]}  {item.category.toUpperCase()}</Text>
      <Pressable onPress={(e) => { e.stopPropagation(); onSave(); }} hitSlop={10}><Text style={{ color: saved ? C.lime : C.muted, fontSize: 22 }}>{saved ? "♥" : "♡"}</Text></Pressable>
    </View>
    <Text style={{ color: C.text, fontSize: 20, fontWeight: "800", marginTop: 10 }}>{item.name}</Text>
    <Text style={{ color: C.muted, marginTop: 5 }}>{item.city} · {item.region}</Text>
    <Text style={{ color: C.text, lineHeight: 21, marginTop: 10 }}>{item.description}</Text>
    <View style={{ flexDirection: "row", justifyContent: "space-between", marginTop: 14 }}>
      <Text style={{ color: C.orange, fontWeight: "700" }}>{item.dateLabel ?? item.priceLabel ?? "Details ansehen"}</Text>
      <Text style={{ color: C.muted, fontSize: 12 }}>{item.verified ? "✓ geprüft" : "Demo-Eintrag"}</Text>
    </View>
  </Pressable>;
}
export default function App() {
  const [tab, setTab] = useState<"Heute"|"Entdecken"|"Merkliste"|"Profil">("Heute");
  const [category, setCategory] = useState<Category>("Alle");
  const [city, setCity] = useState("Alle Regionen");
  const [query, setQuery] = useState("");
  const [places, setPlaces] = useState<Place[]>(demoPlaces);
  const [saved, setSaved] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [source, setSource] = useState("demo");

  useEffect(() => {
    (async () => {
      try {
        const raw = await AsyncStorage.getItem("regio:favorites");
        if (raw) setSaved(JSON.parse(raw));
        const live = await fetchPlaces();
        if (live && live.length) { setPlaces(live); setSource("live"); }
      } catch (err) {
        console.warn("REGIO initial load:", err);
      } finally { setLoading(false); }
    })();
  }, []);

  const toggleSave = async (id: string) => {
    const next = saved.includes(id) ? saved.filter(x => x !== id) : [...saved, id];
    setSaved(next);
    try { await AsyncStorage.setItem("regio:favorites", JSON.stringify(next)); } catch {}
  };
  const filtered = useMemo(() => places.filter(p =>
    (category === "Alle" || p.category === category) &&
    (city === "Alle Regionen" || p.city === city) &&
    (tab !== "Merkliste" || saved.includes(p.id)) &&
    `${p.name} ${p.city} ${p.category} ${p.description}`.toLowerCase().includes(query.toLowerCase())
  ), [places, category, city, tab, saved, query]);

  const openDetails = (p: Place) => Alert.alert(p.name, `${p.description}\n\n${p.city}${p.dateLabel ? "\n" + p.dateLabel : ""}${p.priceLabel ? "\n" + p.priceLabel : ""}${p.verified ? "\n\nQuelle geprüft" : "\n\nDemo-Inhalt – nicht als reales Angebot bestätigt."}`, [
    { text: "Schließen", style: "cancel" },
    ...(p.websiteUrl ? [{ text: "Website öffnen", onPress: () => Linking.openURL(p.websiteUrl!) }] : [])
  ]);

  return <SafeAreaView style={{ flex: 1, backgroundColor: C.bg }}>
    <ExpoStatusBar style="light" /><StatusBar barStyle="light-content" backgroundColor={C.bg} />
    <View style={{ paddingHorizontal: 20, paddingTop: 12, paddingBottom: 8 }}>
      <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center" }}>
        <View><Text style={{ color: C.lime, fontSize: 12, fontWeight: "900", letterSpacing: 3 }}>REGIO</Text><Text style={{ color: C.text, fontSize: 28, fontWeight: "900", marginTop: 4 }}>{tab === "Merkliste" ? "Deine Merkliste" : tab === "Profil" ? "Dein Bereich" : "Was geht heute?"}</Text></View>
        <View style={{ backgroundColor: C.panel2, borderRadius: 14, padding: 10 }}><Text style={{ color: C.lime, fontWeight: "800" }}>DACH ↗</Text></View>
      </View>
      {tab !== "Profil" && <TextInput value={query} onChangeText={setQuery} placeholder="Orte, Events und Erlebnisse suchen …" placeholderTextColor={C.muted} style={{ backgroundColor: C.panel, color: C.text, borderRadius: 14, padding: 15, marginTop: 18, borderWidth: 1, borderColor: C.line }} />}
    </View>
    {tab === "Profil" ? <ScrollView contentContainerStyle={{ padding: 20 }}>
      <View style={{ backgroundColor: C.panel, borderRadius: 20, padding: 18 }}><Text style={{ color: C.text, fontSize: 19, fontWeight: "800" }}>REGIO für Deutschland, Österreich & Schweiz</Text><Text style={{ color: C.muted, lineHeight: 22, marginTop: 10 }}>Entdecke Restaurants, Bars, Clubs, Kultur, Sport, Wellness und Veranstaltungen in deiner Region.</Text><Text style={{ color: C.lime, marginTop: 18, fontWeight: "800" }}>Datenmodus: {source === "live" ? "Live-Datenbank" : "Demo-Daten"}</Text><Text style={{ color: C.muted, marginTop: 6, fontSize: 12 }}>Demo-Inhalte sind Platzhalter und keine bestätigten Veranstaltungstipps.</Text></View>
      <Text style={{ color: C.text, fontWeight: "800", fontSize: 18, marginTop: 24, marginBottom: 12 }}>Region auswählen</Text>
      <View style={{ flexDirection: "row", flexWrap: "wrap" }}>{cities.map(c => <Pill key={c} label={c} active={city === c} onPress={() => setCity(c)} />)}</View>
    </ScrollView> : <ScrollView contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 110 }}>
      {tab !== "Merkliste" && <>
        <Text style={{ color: C.muted, fontSize: 13, marginTop: 10, marginBottom: 12 }}>{city === "Alle Regionen" ? "IN DEINER DACH-REGION" : `IN ${city.toUpperCase()}`}</Text>
        <ScrollView horizontal showsHorizontalScrollIndicator={false}>{categories.map(c => <Pill key={c} label={c} active={category === c} onPress={() => setCategory(c)} />)}</ScrollView>
      </>}
      <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginTop: 8, marginBottom: 12 }}>
        <Text style={{ color: C.text, fontSize: 18, fontWeight: "800" }}>{tab === "Merkliste" ? "Gespeichert" : tab === "Entdecken" ? "Entdecken" : "Highlights"}</Text>
        <Text style={{ color: C.muted, fontSize: 12 }}>{filtered.length} Treffer</Text>
      </View>
      {loading && <ActivityIndicator color={C.lime} style={{ marginVertical: 20 }} />}
      {!loading && filtered.length === 0 && <Text style={{ color: C.muted, textAlign: "center", padding: 30 }}>Keine Treffer. Passe Suche oder Filter an.</Text>}
      {filtered.map(p => <Card key={p.id} item={p} saved={saved.includes(p.id)} onSave={() => toggleSave(p.id)} onOpen={() => openDetails(p)} />)}
      <Text style={{ color: C.muted, fontSize: 11, textAlign: "center", marginTop: 12 }}>REGIO · {source === "live" ? "Live-Daten" : "Beispieldaten"} · Angebote vor Besuch beim Veranstalter prüfen</Text>
    </ScrollView>}
    <View style={{ position: "absolute", bottom: 0, left: 0, right: 0, flexDirection: "row", backgroundColor: "#17191E", borderTopWidth: 1, borderTopColor: C.line, paddingTop: 12, paddingBottom: 18, justifyContent: "space-around" }}>
      {(["Heute","Entdecken","Merkliste","Profil"] as const).map((t, i) => <Pressable key={t} onPress={() => { setTab(t); if (t === "Heute" || t === "Entdecken") setCategory("Alle"); }} style={{ alignItems: "center", minWidth: 64 }}><Text style={{ color: tab === t ? C.lime : C.muted, fontSize: 18 }}>{["⌂","⌕","♡","◎"][i]}</Text><Text style={{ color: tab === t ? C.lime : C.muted, fontSize: 10, marginTop: 3, fontWeight: "700" }}>{t}</Text></Pressable>)}
    </View>
  </SafeAreaView>;
}
