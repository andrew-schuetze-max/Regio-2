import { supabase } from "./supabase";
import { Place } from "../types";

function mapRow(row: any): Place {
  return {
    id: String(row.id),
    name: row.name,
    category: row.category,
    city: row.city,
    region: row.region ?? "",
    description: row.description ?? "",
    dateLabel: row.date_label ?? null,
    priceLabel: row.price_label ?? null,
    imageUrl: row.image_url ?? null,
    websiteUrl: row.website_url ?? null,
    verified: Boolean(row.verified),
    featured: Boolean(row.featured)
  };
}

export async function fetchPlaces(): Promise<Place[] | null> {
  if (!supabase) return null;
  const { data, error } = await supabase
    .from("places")
    .select("id,name,category,city,region,description,date_label,price_label,image_url,website_url,verified,featured")
    .eq("published", true)
    .order("featured", { ascending: false })
    .order("created_at", { ascending: false })
    .limit(100);
  if (error) throw error;
  return (data ?? []).map(mapRow);
}
