import { Place } from "../types";

export const demoPlaces: Place[] = [
  { id: "demo-1", name: "Lichtermarkt am Fluss", category: "Event", city: "Hannover", region: "Niedersachsen", description: "Ein stimmungsvoller Abendmarkt mit regionalem Essen, Design und Musik.", dateLabel: "Dieses Wochenende", priceLabel: "Eintritt frei", verified: false, featured: true },
  { id: "demo-2", name: "Kulturhalle Nord", category: "Kultur", city: "Hamburg", region: "Hamburg", description: "Konzerte, Ausstellungen und unabhängige Kultur an einem Ort.", priceLabel: "Ab 12 €", verified: false },
  { id: "demo-3", name: "Studio Balance", category: "Wellness", city: "Berlin", region: "Berlin", description: "Sauna, Ruhebereiche und geführte Entspannung.", priceLabel: "Ab 19 €", verified: false },
  { id: "demo-4", name: "Alte Werft", category: "Bar", city: "Bremen", region: "Bremen", description: "Cocktails und kleine Gerichte in entspannter Hafenatmosphäre.", priceLabel: "€€", verified: false },
  { id: "demo-5", name: "Waldpfad Erlebnispark", category: "Aktivität", city: "Salzburg", region: "Salzburg", description: "Outdoor-Erlebnis mit Naturpfaden und Aussichtspunkten.", priceLabel: "Ab 8 €", verified: false },
  { id: "demo-6", name: "Riverside Run Club", category: "Sport", city: "Zürich", region: "Zürich", description: "Offener Lauftreff für verschiedene Leistungsstufen.", dateLabel: "Jeden Mittwoch", priceLabel: "Kostenlos", verified: false },
  { id: "demo-7", name: "Marktküche", category: "Restaurant", city: "München", region: "Bayern", description: "Saisonale Küche mit Produkten aus der Region.", priceLabel: "€€", verified: false },
  { id: "demo-8", name: "Nachtatelier", category: "Club", city: "Wien", region: "Wien", description: "Elektronische Musik und lokale DJs.", dateLabel: "Fr & Sa", priceLabel: "Ab 10 €", verified: false }
];
