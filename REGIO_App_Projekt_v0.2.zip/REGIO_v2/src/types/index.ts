export type Category =
  | "Alle" | "Restaurant" | "Bar" | "Club" | "Event"
  | "Kultur" | "Sport" | "Wellness" | "Aktivität";

export type Place = {
  id: string;
  name: string;
  category: Exclude<Category, "Alle">;
  city: string;
  region: string;
  description: string;
  dateLabel?: string | null;
  priceLabel?: string | null;
  imageUrl?: string | null;
  websiteUrl?: string | null;
  verified: boolean;
  featured?: boolean;
};
